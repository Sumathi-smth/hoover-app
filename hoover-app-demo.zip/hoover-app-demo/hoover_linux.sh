java -jar jar/demo-0.0.1.jar
