import com.hoover.exception.HooverException;
import com.hoover.main.HooverService;
import com.hoover.main.Output;
import com.hoover.model.Position;
import org.junit.Assert;
import org.junit.Test;

import java.awt.*;
import java.net.URISyntaxException;

public class TestHooverMain {
    
    @Test
    public void validData() throws URISyntaxException,  HooverException {
        String filePath = TestUtils.getFilePath("data/input2.txt");
        HooverService main = new HooverService();
        main.setFilePath(filePath);
        Output output = main.run();
        Assert.assertNotNull(output);
        Output expectedOutput = new Output(new Position(new Point(0,3),null), 2);
        Assert.assertEquals(expectedOutput.getCoords(), output.getCoords());
        Assert.assertEquals(expectedOutput.getDirtsCleaned(), output.getDirtsCleaned());
    }

    @Test
    public void invalidRoomDimension() throws URISyntaxException,  HooverException {
        String filePath = TestUtils.getFilePath("data/invalidRoomDimension.txt");
        HooverService main = new HooverService(filePath);
        main.run();
    }

    @Test
    public void roomDimensionWithAlphabet() throws URISyntaxException,  HooverException {
        String filePath = TestUtils.getFilePath("data/roomDimensionWithAlphabet.txt");
        HooverService main = new HooverService(filePath);
        main.run();
    }
}
