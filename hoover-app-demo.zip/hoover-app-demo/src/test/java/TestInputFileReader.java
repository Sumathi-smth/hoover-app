import com.hoover.exception.HooverException;
import com.hoover.parsers.HooverParser;
import com.hoover.parsers.JsonParser;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class TestInputFileReader {
    JsonParser inputFile;

    @Before
    public void initialise() {
        inputFile = new JsonParser();
    }

    @Test
    public void testValidPath() throws HooverException, URISyntaxException {
        File inputFile = TestUtils.getResourceFile("data/input.txt");
        HooverParser contents = this.inputFile.parse(inputFile.getPath());
        Assert.assertNotNull(contents);
        HooverParser expected = getExpectedObject();
        Assert.assertEquals(expected.getRoomSize(), contents.getRoomSize());
        Assert.assertEquals(expected.getCoords(), contents.getCoords());
        Assert.assertNotNull(contents.getInstructions());
    }

    private HooverParser getExpectedObject() throws HooverException {
        List<Integer> roomSize = Arrays.asList(5, 5);
        List<Integer> coords = Arrays.asList(1, 2);
        HooverParser parser = new HooverParser();
        parser.setRoomSize(roomSize);
        parser.setCoords(coords);
        parser.setInstructions("NNESEESWNWW");

        return parser;
    }


    @Test(expected = HooverException.class)
    public void invalidPath() throws IOException, HooverException {
        //invalid path
        HooverParser parser = inputFile.parse("G:/test/input.txt");

    }

    @Test(expected = HooverException.class)
    public void nullFile() throws IOException, HooverException {
        //invalid null
        HooverParser parser = inputFile.parse(null);
    }

    @Test(expected = HooverException.class)
    public void invalidFileFormat() throws IOException, HooverException {
        //invalid file format
        HooverParser parser = inputFile.parse("C:/abtext.txt");
    }


}
