package com.hoover.parsers;

import com.hoover.exception.HooverException;
import com.hoover.model.DrivingInstructions;
import com.hoover.model.Patch;
import com.hoover.model.Position;
import com.hoover.model.RoomDimension;
import org.springframework.context.annotation.Bean;

import java.awt.*;
import java.util.List;

public class HooverParser {

    private RoomDimension roomSize;
    private Position coords;
    private Patch patches;
    private DrivingInstructions instructions;


    public RoomDimension getRoomSize() {
        return roomSize;
    }


    public void setRoomSize(List<Integer> roomSize) throws HooverException {
        if (roomSize.size() == 2) {
            this.roomSize = new RoomDimension(roomSize.get(0) , roomSize.get(1));
        } else {
            throw new HooverException("Invalid room size.");
        }
    }

    public Position getCoords() {
        return coords;
    }

    public void setCoords(List<Integer> coords) {
        if (coords.size() == 2) {
            this.coords =  new Position(coords.get(0), coords.get(1), roomSize);
        }
    }

    public Patch getPatches() {
        return patches;
    }

    public void setPatches(List<List<Integer>> patchList) throws HooverException {
        if (patchList.size() > 0) {
            this.patches = new Patch(roomSize);
            int index = 0;
            for (List<Integer> pList : patchList) {
                Point point = new Point(pList.get(0), pList.get(1));
                this.patches.applyDirt(point, index);
                index++;
            }
        }

    }

    public DrivingInstructions getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) throws HooverException {
        this.instructions = new DrivingInstructions(instructions);
    }

    @Override
    public String toString() {
        return "HooverParser{" +
                "roomSize=" + roomSize +
                ", coords=" + coords +
                ", patches=" + patches +
                ", instructions='" + instructions + '\'' +
                '}';
    }
}
