package com.hoover.main;

import com.hoover.model.DrivingInstructions;
import com.hoover.model.Patch;
import com.hoover.model.Position;

import java.util.List;
import java.util.ListIterator;

public class Hoovering {

    private Patch patch = null;
    private Position position = null;
    private int dirtsCleaned = 0;
    Position previousPosition = null;


    public Hoovering(Patch patch, Position position) {
        this.patch = patch;
        this.position = position;
        previousPosition = new Position(position);
    }

    private void move(char direction) {
        previousPosition.setLocation(position);
        switch (direction) {
            case 'N':
                position.y++;
                break;
            case 'S':
                position.y--;
                break;
            case 'E':
                position.x++;
                break;
            case 'W':
                position.x--;
                break;
            default:
                break;
        }

        if(position.isValid()) {
            doClean(position);
        } else {
            position.setLocation(previousPosition);
        }
    }

    public Output clean(DrivingInstructions drivingInstructions) {

        Output output = null;

        if (position.isValid()) {
            doClean(position);
        }

        List<Character> instructionList = drivingInstructions.getInstructions();
        for (ListIterator<Character> iter = instructionList.listIterator();
             iter.hasNext(); ) {
            Character direction = iter.next();
            move(direction);
        }

        output = new Output(position, dirtsCleaned);

        return output;
    }

    private void doClean(Position position) {
        if (patch.containsDirt(position)) {
            dirtsCleaned++;
        }
    }
}
