package com.hoover.main;

import com.hoover.exception.HooverException;
import com.hoover.parsers.HooverParser;
import com.hoover.parsers.JsonParser;
import com.hoover.utils.MyLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.logging.Level;

@Service
public class HooverService {

    private String filePath;

    private HooverParser hooverParser;

    private Output output = null;

    public HooverService(String filePath) {
        this();
        this.setFilePath(filePath);
    }

    public HooverService() {
        MyLogger.LOGGER.log(Level.INFO, "Autowired Hoover Service");
    }

    public static void main(String[] args) throws HooverException {
        if (args.length > 0) {
            MyLogger.LOGGER.log(Level.INFO, "main method contains an argument for path - \n" + args[0]);
            HooverService hooverDemo = new HooverService(args[0]);
            hooverDemo.run();
        }
    }

    public Output run() throws HooverException {
        boolean isValid = true;

        //validate the parsed hoover object
        isValid = isValid && validate(hooverParser);

        if (isValid) {
            Hoovering hoover = new Hoovering(hooverParser.getPatches(), hooverParser.getCoords());
            output = hoover.clean(hooverParser.getInstructions());

            if (output != null) {
                MyLogger.LOGGER.log(Level.INFO, "Successfully cleaned the Position ");
              /*  ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
                String json = ow.writeValueAsString(output);
                System.out.println(json);*/
                MyLogger.LOGGER.log(Level.INFO, output.toString());
            }
            return output;
        }

        return null;
    }

    private boolean validate(HooverParser hooverParser) throws HooverException {
        if (!hooverParser.getRoomSize().isValid()) {
            throw new HooverException("Invalid room size");
        } else if (!hooverParser.getCoords().isValid()) {
            throw new HooverException("Invalid coords");
        } else if (!hooverParser.getPatches().isValid()) {
            throw new HooverException("Invalid patches");
        }

        return true;
    }


    public HooverParser getHooverParser() {
        return hooverParser;
    }

    public void setHooverParser(HooverParser parser) {
        this.hooverParser = parser;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public Output getOutput() {
        return output;
    }
}
