package com.hoover.main;

import com.hoover.model.Position;

public class Output {

    private Position coords;
    private int dirtsCleaned;

    public Output(Position position, int dirtsCleaned) {
        this.coords = position;
        this.dirtsCleaned = dirtsCleaned;
    }

    public Position getCoords() {
        return coords;
    }

    public void setCoords(Position coords) {
        this.coords = coords;
    }

    public int getDirtsCleaned() {
        return dirtsCleaned;
    }

    public void setDirtsCleaned(int dirtsCleaned) {
        this.dirtsCleaned = dirtsCleaned;
    }

}
