package com.hoover.validation;

public interface Validate {

    boolean isValid();
}
