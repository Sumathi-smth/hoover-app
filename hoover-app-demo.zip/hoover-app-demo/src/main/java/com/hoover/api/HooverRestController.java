package com.hoover.api;

import com.hoover.exception.HooverException;
import com.hoover.main.HooverService;
import com.hoover.main.Output;
import com.hoover.parsers.HooverParser;
import com.hoover.utils.MyLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Level;

@RestController
public class HooverRestController {

    @Autowired
    private HooverService hooverService;

    @PostMapping(path = "/hoover",
    consumes = {MediaType.APPLICATION_JSON_VALUE},
    produces = {MediaType.APPLICATION_JSON_VALUE})
    public Output getHooverInput(@RequestBody HooverParser hooverInput) throws Exception {
        Output output = null;
        hooverService.setHooverParser(hooverInput);
        try {
            output = hooverService.run();
        } catch (HooverException e) {
            MyLogger.LOGGER.log(Level.SEVERE, e.getMessage());
            throw e;
        }
        return output;
    }

}
