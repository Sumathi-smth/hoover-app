package com.hoover.utils;

public enum PatchType {
    CLEAN,
    DIRTY
}
