package com.hoover.utils;

import java.util.logging.Logger;

public class MyLogger {

    // assumes the current class is called MyLogger
    public final static Logger LOGGER = Logger.getLogger(MyLogger.class.getName());
}
