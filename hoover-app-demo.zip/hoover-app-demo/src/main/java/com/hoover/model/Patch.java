package com.hoover.model;

import com.hoover.exception.HooverException;
import com.hoover.utils.PatchType;
import com.hoover.validation.Validate;

import java.awt.*;

public class Patch implements Validate {

    private PatchType[][] patch;

    private RoomDimension dimension;

    public Patch(RoomDimension dimension) {
        this.dimension = dimension;
        patch =  new PatchType[dimension.x][dimension.y];

        for (int x = 0; x < dimension.x; x++) {
            for (int y = 0; y < dimension.y; y++) {
                patch[x][y] = PatchType.CLEAN;
            }
        }
    }

    public void applyDirt(Point point, int index) throws HooverException {
        applyDirt(point.x, point.y, index);
    }

    public void applyDirt(int x, int y, int index) throws HooverException {
        if (x >= dimension.x ||
                y >= dimension.y) {
            throw new HooverException("Unable to apply dirt for the ", index);
        }
        patch[x][y] = PatchType.DIRTY;
    }

    public boolean containsDirt(Point point) {
        if(patch[point.x][point.y] == PatchType.DIRTY) {
            patch[point.x][point.y] = PatchType.CLEAN;
            return true;
        }
        return  false;
    }

    @Override
    public boolean isValid() {
        return dimension.isValid();
    }
}
